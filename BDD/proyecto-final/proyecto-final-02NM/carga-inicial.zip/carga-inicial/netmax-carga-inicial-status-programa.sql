insert into status_programa(status_programa_id,clave,descripcion) values(1,'PROGRAMADO','El programa está en la base de datos pero aun no disponible para consumo');
insert into status_programa(status_programa_id,clave,descripcion) values(2,'DISPONIBLE','El cliente puede hacer streaming sobre el');
insert into status_programa(status_programa_id,clave,descripcion) values(3,'SATURADO','Programa disponible con una gran demanda.');
insert into status_programa(status_programa_id,clave,descripcion) values(4,'NO DISPONIBLE','El cliente ya no puede hacer streaming');
insert into status_programa(status_programa_id,clave,descripcion) values(5,'OBSOLETO','Programa que ya concluyó con su ciclo de vida');



