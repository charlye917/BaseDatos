insert into tipo_cuenta(tipo_cuenta_id,clave,descripcion,costo_mensual) values(1,'BASICA','Cuenta básica  gratuita',0.00);
insert into tipo_cuenta(tipo_cuenta_id,clave,descripcion,costo_mensual) values(2,'PROFESIONAL','Cuenta enfocada al desarrollo profesional',20.00);
insert into tipo_cuenta(tipo_cuenta_id,clave,descripcion,costo_mensual) values(3,'VIP','Cuenta con los mayores beneficios, genera cargos',150.45);

