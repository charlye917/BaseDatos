--@Autor:          Jorge A. Rodríguez C
--@Fecha creación:  dd/mm/yyyy
--@Descripción:     Archivo de carga inicial.

Prompt ======================================
Prompt validando transparencia en jrcbd_s1
Prompt ======================================
connect netmax_bdd/netmax_bdd@jrcbd_s1
whenever sqlerror exit rollback;

set serveroutput on
declare
	v_count number(10,0);
begin
	
	dbms_output.put_line('Poblando USUARIO');
	@carga-inicial/netmax-carga-inicial-usuario.sql

	dbms_output.put_line('Validando USUARIO');
	select count(*) into v_count from usuario;
	if v_count <> 1000 then
		raise_application_error(-20005,'Se esperaban 1000 registros, solo se tienen '||v_count);
	end if;

	dbms_output.put_line('Vaciando tabla Playlist');
	delete from playlist;
	dbms_output.put_line('Verificando registros eliminados');

	select count(*) into v_count from playlist;
	if v_count > 0 then
		raise_application_error(-20005,'No se eliminaron los registros de playlist');
	end if;
		
	select count(*) into v_count from playlist_f1;
	if v_count > 0 then
		raise_application_error(-20005,'No se eliminaron los registros de playlist_f1');
	end if;

	select count(*) into v_count from playlist_f2;
	if v_count > 0 then
		raise_application_error(-20005,'No se eliminaron los registros de playlist_f2');
	end if;

	select count(*) into v_count from playlist_f3;
	if v_count > 0 then
		raise_application_error(-20005,'No se eliminaron los registros de playlist_f3');
	end if;
	dbms_output.put_line('VALIDACION DE ELIMINACION OK !');


	rollback;

exception
	when others then
		rollback;
		raise;
end;
/




