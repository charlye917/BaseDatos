connect sys/system@jrcbd_s1 as sysdba
prompt creando usuario medicos
create user medicos identified by medicos quota unlimited on users;
grant create session, create table to medicos;
prompt done.


